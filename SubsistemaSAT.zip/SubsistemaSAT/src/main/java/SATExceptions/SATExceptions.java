/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SATExceptions;

/**
 *
 * @author cesar
 */
public class SATExceptions extends Exception{
    public SATExceptions(String mensaje) {
        super(mensaje);
    }
}
