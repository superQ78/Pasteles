/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExceptionPedido;

/**
 *
 * @author cesar
 */
    public class PedidoException extends Exception {
    public PedidoException(String mensaje) {
        super(mensaje);
    }
}

